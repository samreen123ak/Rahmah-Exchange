export default function Loading() {}
