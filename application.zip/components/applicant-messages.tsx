"use client"

import { useEffect, useState, useRef } from "react"
import { Send, Paperclip, AlertCircle, CheckCircle2 } from "lucide-react"

interface Message {
  _id: string
  body: string
  senderName: string
  senderEmail: string
  senderRole: string
  createdAt: string
  attachments: any[]
}

interface ApplicantMessagesProps {
  caseId: string
  conversationId: string
  className?: string
  maxHeight?: string
}

function Toast({ message, type, isVisible }: { message: string; type: "success" | "error"; isVisible: boolean }) {
  if (!isVisible) return null
  return (
    <div
      className={`fixed top-4 right-4 p-4 rounded-lg flex items-center gap-2 text-white font-semibold z-50 ${
        type === "success" ? "bg-green-500" : "bg-red-500"
      }`}
    >
      {type === "success" ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
      {message}
    </div>
  )
}

export default function ApplicantMessages({
  caseId,
  conversationId,
  className = "",
  maxHeight = "h-[500px]",
}: ApplicantMessagesProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [newMessage, setNewMessage] = useState("")
  const [participants, setParticipants] = useState<any[]>([])
  const [currentUserId, setCurrentUserId] = useState<string>("")
  const msgEndRef = useRef<HTMLDivElement | null>(null)

  const [toast, setToast] = useState<{ message: string; type: "success" | "error"; isVisible: boolean }>({
    message: "",
    type: "success",
    isVisible: false,
  })

  const showToast = (message: string, type: "success" | "error") => {
    setToast({ message, type, isVisible: true })
    setTimeout(() => setToast((prev) => ({ ...prev, isVisible: false })), 4000)
  }

  // Auto-scroll to last message
  const scrollToBottom = () => {
    msgEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(scrollToBottom, [messages])

  useEffect(() => {
    fetchConversationDetails()
    fetchMessages()
  }, [conversationId])

  const fetchConversationDetails = async () => {
    try {
      const token = sessionStorage.getItem("applicantToken")
      const applicantId = sessionStorage.getItem("applicantId")

      if (!applicantId) return

      setCurrentUserId(applicantId)

      const response = await fetch(
        `/api/applicant/messages/conversations/${conversationId}?details=true`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )

      if (!response.ok) return

      const data = await response.json()
      if (data.conversation?.participants) {
        setParticipants(data.conversation.participants)
      }
    } catch (error) {
      console.error("Error fetching details", error)
    }
  }

  const fetchMessages = async () => {
    try {
      setLoading(true)
      const token = sessionStorage.getItem("applicantToken")

      const response = await fetch(
        `/api/applicant/messages/conversations/${conversationId}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )

      if (!response.ok) throw new Error("Failed to load messages")

      const data = await response.json()
      setMessages(data.messages)
    } catch (error) {
      showToast("Failed to load messages", "error")
    } finally {
      setLoading(false)
    }
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    setSending(true)

    try {
      const token = sessionStorage.getItem("applicantToken")
      const formData = new FormData()

      formData.append("conversationId", conversationId)
      formData.append("body", newMessage)
      formData.append("messageType", "text")

      // send only to staff
      participants.forEach((p) => {
        if (p.role !== "applicant" && p.userId) {
          formData.append("recipientIds", p.userId)
        }
      })

      const response = await fetch("/api/applicant/messages/send", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      })

      if (!response.ok) throw new Error("Failed to send message")

      showToast("Message sent", "success")
      setNewMessage("")
      fetchMessages()
    } catch (error: any) {
      showToast(error.message || "Error sending message", "error")
    } finally {
      setSending(false)
    }
  }

  // Get initials for avatar
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((word) => word[0])
      .join("")
      .toUpperCase()
  }

  return (
    <div className={`bg-white rounded-2xl shadow-sm border border-gray-200 flex flex-col ${maxHeight} ${className}`}>
      <Toast message={toast.message} type={toast.type} isVisible={toast.isVisible} />

      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <h3 className="font-semibold text-gray-900">Communication Thread</h3>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-3 bg-[#e5ddd5]">
        {loading ? (
          <div className="flex justify-center pt-10">
            <div className="animate-spin h-8 w-8 border-b-2 border-teal-600 rounded-full"></div>
          </div>
        ) : messages.length === 0 ? (
          <div className="text-gray-500 text-center pt-10">No messages yet.</div>
        ) : (
          messages.map((msg) => {
            const isMine = msg.senderRole === "applicant"

            return (
              <div key={msg._id} className={`w-full flex mb-3 ${isMine ? "justify-end" : "justify-start"}`}>
                <div className={`flex items-end gap-2 max-w-[75%]`}>
                  
                  {/* Avatar for team messages */}
                  {!isMine && (
                    <div className="w-8 h-8 rounded-full bg-gray-400 text-white text-xs font-bold flex items-center justify-center">
                      {getInitials(msg.senderName)}
                    </div>
                  )}

                  {/* Bubble */}
                  <div
                    className={`px-4 py-2 rounded-2xl shadow text-sm whitespace-pre-wrap break-words ${
                      isMine
                        ? "bg-teal-600 text-white rounded-br-none"
                        : "bg-white text-gray-800 rounded-bl-none"
                    }`}
                  >
                    {msg.body}

                    {/* Attachments */}
                    {msg.attachments?.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {msg.attachments.map((att: any, i: number) => (
                          <a
                            key={i}
                            href={att.url}
                            target="_blank"
                            className="flex items-center gap-1 text-xs underline"
                          >
                            <Paperclip className="w-3 h-3" /> {att.originalname}
                          </a>
                        ))}
                      </div>
                    )}

                    {/* Time */}
                    <p className={`text-[10px] mt-1 ${isMine ? "text-teal-100" : "text-gray-500"}`}>
                      {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              </div>
            )
          })
        )}

        <div ref={msgEndRef}></div>
      </div>

      {/* Input */}
      <form onSubmit={handleSendMessage} className="p-3 border-t border-gray-300 bg-white flex gap-2">
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type a message…"
          className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-full focus:ring-2 focus:ring-teal-600"
        />

        <button
          type="submit"
          disabled={sending || !newMessage.trim()}
          className="px-4 py-2 bg-teal-600 text-white rounded-full hover:bg-teal-700 disabled:opacity-50"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  )
}
