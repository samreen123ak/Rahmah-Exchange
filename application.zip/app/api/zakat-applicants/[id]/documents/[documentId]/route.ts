import { type NextRequest, NextResponse } from "next/server"
import { dbConnect } from "@/lib/db"
import ZakatApplicant from "@/lib/models/ZakatApplicant"
import DocumentAudit from "@/lib/models/DocumentAudit"
import { verifyApplicantToken } from "@/lib/applicant-token-utils"
import { deleteStored } from "@/lib/storage"

// DELETE document (applicant)
export async function DELETE(request: NextRequest, context: any) {
  try {
    const { params } = context
    const applicantId = (await params).id
    const documentId = (await params).documentId

    // Verify token
    const token = new URL(request.url).searchParams.get("token")
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyApplicantToken(token)
    if (!decoded || decoded.applicantId !== applicantId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    await dbConnect()

    const applicant = await ZakatApplicant.findById(applicantId)
    if (!applicant) {
      return NextResponse.json({ error: "Application not found" }, { status: 404 })
    }

    // Find the document
    const docIndex = applicant.documents.findIndex(
      (d: any) => d._id.toString() === documentId || d.filename === documentId
    )
    if (docIndex === -1) {
      return NextResponse.json({ error: "Document not found" }, { status: 404 })
    }

    const document = applicant.documents[docIndex]

    // Delete from storage (Vercel Blob or local)
    try {
      await deleteStored(document.url)
    } catch (err) {
      console.error("File deletion error:", err)
    }

    // Remove from documents array
    applicant.documents.splice(docIndex, 1)
    await applicant.save()

    // Log this deletion
    const audit = new DocumentAudit({
      applicantId,
      documentId: document.filename,
      action: "deleted",
      actionBy: "applicant",
      uploadedBy: applicant.email,
      originalFilename: document.originalname,
      fileSize: document.size,
      mimeType: document.mimeType,
    })
    await audit.save()

    return NextResponse.json({ message: "Document deleted successfully" }, { status: 200 })
  } catch (error: any) {
    console.error("DELETE document error:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
