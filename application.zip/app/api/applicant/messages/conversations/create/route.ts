import { type NextRequest, NextResponse } from "next/server"
import mongoose from "mongoose"
import { dbConnect } from "@/lib/db"
import { verifyApplicantToken } from "@/lib/applicant-token-utils"
import Conversation from "@/lib/models/Conversation"
import ZakatApplicant from "@/lib/models/ZakatApplicant"
import User from "@/lib/models/User"

// POST - Create or get conversation for applicant
export async function POST(request: NextRequest) {
  try {
    // Get token from Authorization header or query params
    const authHeader = request.headers.get("authorization")
    let token = ""

    if (authHeader?.startsWith("Bearer ")) {
      token = authHeader.slice(7)
    } else {
      token = new URL(request.url).searchParams.get("token") || ""
    }

    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyApplicantToken(token)
    if (!decoded) {
      return NextResponse.json({ message: "Invalid or expired token" }, { status: 401 })
    }

    const applicantId = decoded.applicantId

    const body = await request.json()
    const { conversationId, title } = body

    if (!applicantId) {
      return NextResponse.json({ error: "Invalid applicant token" }, { status: 401 })
    }

    await dbConnect()

    // Get the applicant
    const applicant = await ZakatApplicant.findById(applicantId)
    if (!applicant) {
      return NextResponse.json({ error: "Applicant not found" }, { status: 404 })
    }

    // Use provided conversationId or generate one
    const convId = conversationId || `applicant-${applicantId}`

    // Check if conversation already exists
    let conversation = await Conversation.findOne({ conversationId: convId })

    if (conversation) {
      // 🔧 FIX: Add admins if they're missing from existing conversation
      try {
        const adminUsers = await User.find({ role: { $in: ["admin", "caseworker", "approver"] } })
        let conversationUpdated = false
        
        console.log(`Found ${adminUsers.length} admin users to potentially add`)
        
        for (const admin of adminUsers) {
          const alreadyParticipant = conversation.participants.some(
            (p: any) => p.userId?.toString() === admin._id.toString()
          )
          
          if (!alreadyParticipant) {
            conversation.participants.push({
              userId: admin._id,
              email: admin.email,
              internalEmail: admin.internalEmail || admin.email,
              name: `${admin.firstName || ''} ${admin.lastName || ''}`.trim() || admin.email,
              role: admin.role,
              joinedAt: new Date(),
              lastReadAt: new Date(0),
              isActive: true,
            })
            conversationUpdated = true
            console.log(`✅ Added admin ${admin.email} to conversation ${convId}`)
          }
        }
        
        if (conversationUpdated) {
          await conversation.save()
          console.log(`✅ Conversation updated with admin participants. Total participants: ${conversation.participants.length}`)
        } else {
          console.log(`ℹ️ All admins already in conversation`)
        }
      } catch (err) {
        console.error("Failed to add admins to existing conversation:", err)
      }
      // 🔧 END FIX
      
      return NextResponse.json(
        { conversation, conversationId: convId, isNew: false },
        { status: 200 }
      )
    }

    // Create new conversation
    // Get admin/staff users to add as participants
    const adminUsers = await User.find({ role: { $in: ["admin", "caseworker", "approver"] } })
    
    console.log(`Creating new conversation with ${adminUsers.length} admin users`)
    
    const participants = [
      {
        userId: applicant._id,
        email: applicant.email,
        internalEmail: applicant.email,
        name: `${applicant.firstName} ${applicant.lastName}`,
        role: "applicant",
        joinedAt: new Date(),
        lastReadAt: new Date(),
        isActive: true,
      },
    ]

    // Add admin/staff users as participants
    for (const admin of adminUsers) {
      participants.push({
        userId: admin._id,
        email: admin.email,
        internalEmail: admin.internalEmail || admin.email,
        name: `${admin.firstName || ''} ${admin.lastName || ''}`.trim() || admin.email,
        role: admin.role,
        joinedAt: new Date(),
        lastReadAt: new Date(),
        isActive: true,
      })
    }

    const conversationTitle =
      title || `Zakat Application - ${applicant.firstName} ${applicant.lastName} (${applicant.caseId})`

    conversation = new Conversation({
      caseId: applicant._id,
      conversationId: convId,
      participants,
      title: conversationTitle,
      description: `Communication thread for applicant ${applicant.caseId}`,
      messageCount: 0,
      lastMessageAt: new Date(),
    })

    try {
      await conversation.save()
      console.log(`✅ Created new conversation with ${participants.length} participants`)
    } catch (saveErr: any) {
      // Handle duplicate key error for unique fields
      if (saveErr?.code === 11000) {
        // E11000 = MongoDB duplicate key error
        const field = Object.keys(saveErr?.keyPattern || {})[0]
        console.warn(`Conversation already exists for ${field}:`, { field, applicantId: applicant._id, convId })
        
        // Try to find and return existing conversation
        const existingConv = await Conversation.findOne({ 
          $or: [
            { caseId: applicant._id },
            { conversationId: convId }
          ]
        })
        
        if (existingConv) {
          return NextResponse.json(
            { conversation: existingConv, conversationId: existingConv.conversationId, isNew: false },
            { status: 200 }
          )
        }
      }
      // Re-throw if not a duplicate key error
      throw saveErr
    }

    return NextResponse.json(
      { conversation, conversationId: convId, isNew: true },
      { status: 201 }
    )
  } catch (error: any) {
    console.error("POST applicant conversation error:", error?.message || error, {
      code: error?.code,
      keyPattern: error?.keyPattern,
      stack: error?.stack,
    })
    
    // Return detailed error in development
    const isDev = process.env.NODE_ENV !== "production"
    return NextResponse.json(
      { 
        error: error?.message || "Failed to create conversation",
        code: isDev ? error?.code : undefined,
        details: isDev ? error?.keyPattern : undefined,
      }, 
      { status: 500 }
    )
  }
}
