import mongoose from "mongoose"

const conversationSchema = new mongoose.Schema(
  {
    // Case reference
    caseId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ZakatApplicant",
      required: true,
      index: true,
      unique: true,
    },
    conversationId: {
      type: String,
      required: true,
      unique: true,
      index: true,
      // Format: "case_[caseObjectId]"
    },

    // Participants
    participants: [
      {
        userId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        email: String,
        internalEmail: String,
        name: String,
        role: {
          type: String,
          enum: ["applicant", "caseworker", "approver"],
        },
        joinedAt: {
          type: Date,
          default: Date.now,
        },
        lastReadAt: Date,
        isActive: {
          type: Boolean,
          default: true,
        },
      },
    ],

    // Conversation metadata
    title: String, // e.g., "Zakat Application - John Smith (CASE-20250114-ABC)"
    description: String,
    messageCount: {
      type: Number,
      default: 0,
    },
    lastMessageAt: Date,
    lastMessage: String,

    // Settings
    isArchived: {
      type: Boolean,
      default: false,
    },
    isMuted: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
)

// Index for fast queries
conversationSchema.index({ caseId: 1, createdAt: -1 })
conversationSchema.index({ "participants.userId": 1 })
conversationSchema.index({ isArchived: 1 })

export default mongoose.models.Conversation ||
  mongoose.model("Conversation", conversationSchema)
